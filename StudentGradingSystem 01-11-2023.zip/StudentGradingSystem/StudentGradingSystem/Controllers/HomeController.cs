﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentGradingSystem.Models;
using StudentGradingSystem.ViewModels;
using System.Diagnostics;

namespace StudentGradingSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;

        public HomeController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login([Bind("UserName,Password")] UserLogin user)
        {
            var isUser = _db.Users.FirstOrDefault(authUser => authUser.Name.Equals(user.UserName) && authUser.Password.Equals(user.Password));
            CoursesTaught.Coorses.Clear();

            if (isUser != null)
            {
                ViewBag.username = string.Format("Successfully logged-in", user.UserName);
                HttpContext.Session.SetString("UserId", isUser.Id.ToString());
                HttpContext.Session.SetString("UserName", isUser.Name);
                HttpContext.Session.SetString("UserType", isUser.Type);
                switch (isUser.Type)
                {
                    case "TEACHER":
                        var courses = _db.Courses.Where(x => x.TeacherId==isUser.Id).Select(x=>x.Id).ToList();
                        foreach (var courseId in courses)
                        {
                            CoursesTaught.Coorses.Add(courseId);
                        }
                        
                        return RedirectToAction("TeacherDashboard", "Dashboard");
                    case "STUDENT":
                        return RedirectToAction("StudentDashboard", "Dashboard");
                    default:
                        break;
                }

                return RedirectToAction("Login", "Home");
            }
            else
            {
                ClearSession();
                ViewBag.username = string.Format("Login Failed: Invalid User Name/Password ", user.UserName);
                return View();
            }
        }
        public ActionResult Logout()
        {
            ClearSession();
            return RedirectToAction("Login");
        }
        public void ClearSession()
        {
            HttpContext.Session.Clear();
            HttpContext.Session.Remove("UserName");
            HttpContext.Session.Remove("UserId");
            HttpContext.Session.Remove("UserType");
        }
    }
}
