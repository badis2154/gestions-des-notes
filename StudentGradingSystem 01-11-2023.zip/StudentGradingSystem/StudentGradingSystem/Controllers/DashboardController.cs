﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentGradingSystem.Models;
using StudentGradingSystem.Utilities;

namespace StudentGradingSystem.Controllers
{
    [Authentication]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _db;
        public DashboardController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var userType = HttpContext.Session.GetString("UserType");
            switch (userType)
            {
                case "TEACHER":
                    return RedirectToAction("TeacherDashboard");
                case "STUDENT":
                    return RedirectToAction("StudentDashboard");
                default:
                    break;
            }
            return RedirectToAction("Login");
        }
        public IActionResult TeacherDashboard()
        {
            var teacherId = Convert.ToInt32(HttpContext.Session.GetString("UserId"));
            var teacher = _db.Teachers.Include(x => x.CoursesTaught).FirstOrDefault(x => x.Id.Equals(teacherId));
            return View(teacher);
        }
        public IActionResult StudentDashboard()
        {
            var studentId = Convert.ToInt32(HttpContext.Session.GetString("UserId"));
            // var student = _db.Students.Include(x => x.Grades).ThenInclude(g => g.Grade).ThenInclude(a => a.Assessments).ThenInclude(c=>c.Course).ThenInclude(t=>t.Teacher).FirstOrDefault(x => x.Id.Equals(studentId));
            var student = _db.Students.Include(x => x.Grades).ThenInclude(g => g.Grade).FirstOrDefault(x => x.Id.Equals(studentId));
            return View(student);
        }
        public IActionResult GradeDetails(int? id)
        {
            var studentId = Convert.ToInt32(HttpContext.Session.GetString("UserId"));
            var grade = _db.GradeStudents.Include(x => x.Grade).ThenInclude(g => g.Assessments).ThenInclude(x => x.Course).FirstOrDefault(x => x.Id.Equals(id));
            return View(grade);
        }
        public IActionResult Courses(string courseTitle)
        {
            var courses = _db.Courses.Include(x => x.Teacher).ToList();
            if (!string.IsNullOrEmpty(courseTitle))
                courses = courses.Where(c => c.Title.ToLower().Contains(courseTitle.ToLower())).ToList();
            return View(courses);
        }

    }
}
