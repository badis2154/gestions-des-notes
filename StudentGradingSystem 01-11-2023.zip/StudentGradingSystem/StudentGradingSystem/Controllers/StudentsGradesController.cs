﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentGradingSystem.Models;
using StudentGradingSystem.Utilities;

namespace StudentGradingSystem.Controllers
{
    [Authentication]
    public class StudentsGradesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentsGradesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: StudentsGrade
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.GradeStudents.Include(g => g.Grade).Include(g => g.Student);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: StudentsGrade/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.GradeStudents == null)
            {
                return NotFound();
            }

            var gradeStudent = await _context.GradeStudents
                .Include(g => g.Grade)
                .Include(g => g.Student)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (gradeStudent == null)
            {
                return NotFound();
            }

            return View(gradeStudent);
        }

        // GET: StudentsGrade/Create
        public IActionResult Create()
        {
            ViewData["GradeId"] = new SelectList(_context.Grades, "Id", "Remark");
            ViewData["StudentId"] = new SelectList(_context.Students, "Id", "Name");
            return View();
        }

        // POST: StudentsGrade/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("GradeId,StudentId")] GradeStudent gradeStudent)
        {
            if (ModelState.IsValid)
            {
                _context.Add(gradeStudent);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["GradeId"] = new SelectList(_context.Grades, "Id", "Remark", gradeStudent.GradeId);
            ViewData["StudentId"] = new SelectList(_context.Students, "Id", "Name", gradeStudent.StudentId);
            return View(gradeStudent);
        }

        // GET: StudentsGrade/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.GradeStudents == null)
            {
                return NotFound();
            }

            var gradeStudent = await _context.GradeStudents.FirstOrDefaultAsync(x=>x.Id==id);
            if (gradeStudent == null)
            {
                return NotFound();
            }
            ViewData["GradeId"] = new SelectList(_context.Grades, "Id", "Remark", gradeStudent.GradeId);
            ViewData["StudentId"] = new SelectList(_context.Students, "Id", "Name", gradeStudent.StudentId);
            return View(gradeStudent);
        }

        // POST: StudentsGrade/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,GradeId,StudentId")] GradeStudent gradeStudent)
        {
            if (id != gradeStudent.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(gradeStudent);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GradeStudentExists(gradeStudent.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["GradeId"] = new SelectList(_context.Grades, "Id", "Remark", gradeStudent.GradeId);
            ViewData["StudentId"] = new SelectList(_context.Students, "Id", "Name", gradeStudent.StudentId);
            return View(gradeStudent);
        }

        // GET: StudentsGrade/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.GradeStudents == null)
            {
                return NotFound();
            }

            var gradeStudent = await _context.GradeStudents
                .Include(g => g.Grade)
                .Include(g => g.Student)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (gradeStudent == null)
            {
                return NotFound();
            }

            return View(gradeStudent);
        }

        // POST: StudentsGrade/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.GradeStudents == null)
            {
                return Problem("Entity set 'ApplicationDbContext.GradeStudents'  is null.");
            }
            var gradeStudent = await _context.GradeStudents.FindAsync(id);
            if (gradeStudent != null)
            {
                _context.GradeStudents.Remove(gradeStudent);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GradeStudentExists(int id)
        {
          return (_context.GradeStudents?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
