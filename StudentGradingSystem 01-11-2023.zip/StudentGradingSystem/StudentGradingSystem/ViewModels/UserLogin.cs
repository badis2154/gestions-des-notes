﻿using System.ComponentModel.DataAnnotations;
namespace StudentGradingSystem.ViewModels
{
    public class UserLogin
    {
        [Required(ErrorMessage = "Please Enter User Name")]
        [Display(Name = "User Name")]
        public string UserName { get; set; } = string.Empty;
        [Required(ErrorMessage = "Please Enter Password")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;
    }
}
