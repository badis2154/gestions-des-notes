﻿namespace StudentGradingSystem.ViewModels
{
    public static class CoursesTaught
    {
        public static List<int> Coorses { get; set; } = new List<int>();
    }
}
