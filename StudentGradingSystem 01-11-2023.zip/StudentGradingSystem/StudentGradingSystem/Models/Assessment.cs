﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentGradingSystem.Models
{
    [Table("Assessment")]
    public class Assessment
    {
        public int Id { get; set; }
        [Display(Name = "Course")]
        [Required(ErrorMessage = "Course is required")]
        public int CourseId { get; set; }
        public string Title { get; set; } = string.Empty;
        [Display(Name = "Result Type")]
        public string ResultType { get; set; } = string.Empty;
        [Display(Name = "Max Grade")]
        [DataType(DataType.PhoneNumber)]
        public double MaxGrade { get; set; }
        [DataType(DataType.PhoneNumber)]
        public double Weight { get; set; }
        public Course? Course{ get; set; }
        public virtual ICollection<Grade>? Grades { get; set; }
    }
}