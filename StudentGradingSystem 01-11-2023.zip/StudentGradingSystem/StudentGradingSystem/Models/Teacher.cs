﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StudentGradingSystem.Models
{
	[Table("Teacher")]
	public class Teacher:User
	{
		public Teacher()
		{
			CoursesTaught = new HashSet<Course>();
		}
		public ICollection<Course> CoursesTaught { get; set; }
    }
}
