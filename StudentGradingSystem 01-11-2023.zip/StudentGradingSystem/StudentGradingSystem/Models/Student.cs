﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StudentGradingSystem.Models
{
	[Table("Student")]
	public class Student:User
	{
		public Student()
		{
			Grades = new HashSet<GradeStudent>();
		}
		public ICollection<GradeStudent> Grades { get; set; }
	}
}
