﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Xml.Linq;

namespace StudentGradingSystem.Models
{
	[Table("Grade")]
	public class Grade
	{
		public Grade()
		{
			Students = new HashSet<GradeStudent>();
        }
		public int Id { get; set; }
        [Display(Name = "Assessment")]
        [Required(ErrorMessage = "Assessment is required")]
        public int AssessmentId { get; set; }
        public double Value { get; set; }
        public string Remark { get; set; } = string.Empty;
        public Assessment? Assessments { get; set; }
		public ICollection<GradeStudent>? Students { get; set; }
	}
}
