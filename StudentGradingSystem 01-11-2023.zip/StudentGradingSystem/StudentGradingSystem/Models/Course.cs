﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Xml.Linq;

namespace StudentGradingSystem.Models
{
	[Table("Course")]
	public class Course
	{

		public Course()
		{
            Assessments = new HashSet<Assessment>();
		}
        public string ScheduleDateSummary
        {
            get
            {
                return Schedule.ToString("yyyy-MM-dd");
            }
        }
        [Display(Name = "Schedule")]
        public string ScheduleTimeSummary
        {
            get
            {
                return Schedule.ToString("h:mm tt");
            }
        }
        public int Id { get; set; }
        [Display(Name ="Teacher")]
        public int TeacherId { get; set; }
		public string Title { get; set; }=string.Empty;
		public string Description { get; set; }= string.Empty;
        [DataType(DataType.Time)]
        public DateTime Schedule { get; set; }
        public string Room { get; set; } = string.Empty;
		public virtual Teacher? Teacher { get; set; }
        public virtual ICollection<Assessment> Assessments { get; set; }
    }
}